/**
 * Dewy design tokens — from DUEY Color System.csv
 * Soft, feminine, elevated, calm, editorial. Never clinical or generic SaaS.
 */

export const colors = {
  /** Porcelain Ivory — primary surface / cream panel */
  porcelainIvory: '#F7F6D7',
  /** Dried Plum — primary ink / labels / borders */
  driedPlum: '#6E1E3B',
  /** Cherry Licorice — primary action / rounded CTA fill or emphasis */
  cherryLicorice: '#A10808',
  /** Buttermilk — soft cues / highlights */
  buttermilk: '#FFF1B5',
  /** Milkshake Pink — personal notes / warm accents */
  milkshakePink: '#EDCCCC',
  /** Soft Silver — dividers / hairlines */
  softSilver: '#C8C5C1',
  /** Field fill — slightly lighter cream nested in porcelain */
  fieldFill: '#FBF9E8',
  /** White for contrast where needed (rare) */
  white: '#FFFFFF',
} as const;

export const spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 40,
} as const;

export const radii = {
  sm: 4,
  md: 8,
  lg: 16,
  /** Pill CTA — highly rounded */
  pill: 999,
} as const;

export const typography = {
  label: {
    fontSize: 15,
    fontWeight: '500' as const,
    letterSpacing: 0.4,
  },
  body: {
    fontSize: 16,
    fontWeight: '400' as const,
  },
  link: {
    fontSize: 15,
    fontWeight: '400' as const,
    textDecorationLine: 'underline' as const,
  },
  cta: {
    fontSize: 16,
    fontWeight: '600' as const,
    letterSpacing: 0.3,
  },
} as const;

export const theme = {
  colors,
  spacing,
  radii,
  typography,
  /** Screen defaults matching Add Product to Cabinet screenshot */
  screen: {
    background: colors.porcelainIvory,
    ink: colors.driedPlum,
    border: colors.driedPlum,
    divider: colors.softSilver,
    fieldBackground: colors.fieldFill,
    primaryAction: colors.cherryLicorice,
    cue: colors.buttermilk,
    note: colors.milkshakePink,
  },
} as const;

export type Theme = typeof theme;
